from django.contrib import admin
from django.urls import path
from core import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('api/chat/', views.chat_api, name='chat_api'),
    path('api/unified_chat/', views.unified_chat, name='unified_chat'),
    path('api/upload_search_image/', views.upload_search_image, name='upload_search_image'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
