from django.shortcuts import render
from transformers import BlipProcessor, BlipForConditionalGeneration
from transformers import CLIPProcessor, CLIPModel
import json
import requests
from django.http import JsonResponse, HttpResponse
from PIL import Image
import os
import torch

# ---------- LOAD MODELS ONCE ----------
clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32", use_fast=True)
clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")

blip_processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base", use_fast=True)
blip_model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")


# ---------- CLIP SEARCH FUNCTION ----------
def clip_search(text_query):
    folder = "media/search_images/"
    image_files = os.listdir(folder)

    # Convert text to embedding
    text_inputs = clip_processor(text=[text_query], return_tensors="pt", padding=True)
    with torch.no_grad():
        text_features = clip_model.get_text_features(**text_inputs)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarities = []

    for img_name in image_files:
        img_path = folder + img_name
        image = Image.open(img_path).convert("RGB")

        # Convert image to embedding
        image_inputs = clip_processor(images=image, return_tensors="pt")
        with torch.no_grad():
            image_features = clip_model.get_image_features(**image_inputs)

        # Normalize image embedding
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)

        # Cosine similarity
        sim = torch.nn.functional.cosine_similarity(text_features, image_features).item()

        similarities.append((sim, img_name))

    # Pick best match
    best_match = max(similarities, key=lambda x: x[0])
    return folder + best_match[1]



# ---------- MAIN VIEW ----------
def home(request):
    image_url = None
    caption = None
    search_result = None

    # HANDLE POST REQUESTS
    if request.method == "POST":

        # 1️⃣ IMAGE UPLOAD + CAPTION (BLIP)
        if "image" in request.FILES:  # safer check
            img = request.FILES["image"]
            img_name = img.name

            # Ensure media folder exists
            media_path = "media"
            if not os.path.exists(media_path):
                os.makedirs(media_path)

            save_path = os.path.join(media_path, img_name)
            with open(save_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)

            # Show uploaded image
            image_url = "/media/" + img_name

            # Generate caption using BLIP
            pil_image = Image.open(save_path).convert("RGB")
            inputs = blip_processor(images=pil_image, return_tensors="pt")
            output = blip_model.generate(**inputs, max_length=20)
            caption = blip_processor.decode(output[0], skip_special_tokens=True)

        # 2️⃣ TEXT SEARCH USING CLIP
        if "query" in request.POST:
            query = request.POST.get("query")
            if query.strip() != "":
                result_path = clip_search(query)
                search_result = "/" + result_path

    # RENDER EVERYTHING
    return render(request, "index.html", {
        "image_url": image_url,
        "caption": caption,
        "search_result": search_result,
    })


def chat_api(request):
    """Simple proxy endpoint to talk to Anthropic Claude Haiku 4.5.

    Expects JSON POST: { "prompt": "..." }

    Notes / assumptions:
    - Reads API key from ANTHROPIC_API_KEY environment variable.
    - Assumes the Anthropic Responses API is available at
      https://api.anthropic.com/v1/responses and accepts
      { model: "claude-haiku-4.5", input: "..." }.
      If your provider uses a different shape, update this function.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)

    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

    prompt = (payload.get('prompt') or '').strip()
    if not prompt:
        return JsonResponse({'error': 'prompt is required'}, status=400)

    api_key = os.environ.get('ANTHROPIC_API_KEY')
    api_url = os.environ.get('ANTHROPIC_API_URL', 'https://api.anthropic.com/v1/responses')

    if not api_key:
        # Not configured — return a helpful message so front-end can fall back.
        return JsonResponse({'error': 'ANTHROPIC_API_KEY not set. Set the environment variable to enable Claude Haiku 4.5.'}, status=501)

    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }

    # Build request body (this is a reasonable default; adapt if your API differs)
    body = {
        'model': os.environ.get('ANTHROPIC_MODEL', 'claude-haiku-4.5'),
        'input': prompt,
    }

    try:
        r = requests.post(api_url, headers=headers, json=body, timeout=30)
        r.raise_for_status()
        resp_json = r.json()

        # Try a few common response shapes
        text = None
        if isinstance(resp_json, dict):
            if 'completion' in resp_json:
                text = resp_json['completion']
            elif 'output' in resp_json:
                # some APIs use 'output'
                text = resp_json['output']
            elif 'choices' in resp_json and isinstance(resp_json['choices'], list) and resp_json['choices']:
                first = resp_json['choices'][0]
                text = first.get('text') or first.get('message') or first.get('content')

        if text is None:
            # Fallback: return the whole JSON as a string
            text = json.dumps(resp_json)

        return JsonResponse({'response': text})

    except requests.RequestException as e:
        return JsonResponse({'error': 'Request to Anthropic failed', 'details': str(e)}, status=502)


def upload_search_image(request):
    """Receive an uploaded image for search and save it to media/search_images.

    Expects form-data with file field named 'search_image'. Returns JSON with
    the saved image url: { success: true, url: '/media/search_images/...' }
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)

    if 'search_image' not in request.FILES:
        return JsonResponse({'error': "'search_image' file is required"}, status=400)

    f = request.FILES['search_image']
    folder = os.path.join('media', 'search_images')
    os.makedirs(folder, exist_ok=True)

    filename = f.name
    base, ext = os.path.splitext(filename)
    dest = os.path.join(folder, filename)
    # make unique
    i = 1
    while os.path.exists(dest):
        filename = f"{base}_{i}{ext}"
        dest = os.path.join(folder, filename)
        i += 1

    with open(dest, 'wb+') as out:
        for chunk in f.chunks():
            out.write(chunk)

    url = '/media/search_images/' + filename

    # Attempt to run an image-to-image CLIP search using the saved image.
    try:
        # Load the uploaded image and compute CLIP image features
        query_image = Image.open(dest).convert('RGB')
        image_inputs = clip_processor(images=query_image, return_tensors='pt')
        with torch.no_grad():
            query_features = clip_model.get_image_features(**image_inputs)
        query_features = query_features / query_features.norm(dim=-1, keepdim=True)

        # Compare against all other images in the folder
        similarities = []
        for img_name in os.listdir(folder):
            # skip comparing to itself
            if img_name == filename:
                continue
            img_path = os.path.join(folder, img_name)
            try:
                img = Image.open(img_path).convert('RGB')
                inputs = clip_processor(images=img, return_tensors='pt')
                with torch.no_grad():
                    feat = clip_model.get_image_features(**inputs)
                feat = feat / feat.norm(dim=-1, keepdim=True)
                sim = torch.nn.functional.cosine_similarity(query_features, feat).item()
                similarities.append((sim, img_name))
            except Exception:
                # skip unreadable images
                continue

        if similarities:
            best = max(similarities, key=lambda x: x[0])
            best_match_name = best[1]
            best_sim = best[0]
            best_url = '/media/search_images/' + best_match_name
        else:
            best_url = None
            best_sim = None

    except Exception as e:
        # If anything fails during matching, return saved url but no match
        best_url = None
        best_sim = None

    return JsonResponse({'success': True, 'url': url, 'best_match': best_url, 'similarity': best_sim})


def unified_chat(request):
    """Unified endpoint that routes chat prompts to search, caption, or Claude based on intent.
    
    Expects JSON POST: { "prompt": "...", "image_url": "..." (optional) }
    
    Returns { response: "...", type: "search"|"caption"|"claude" }
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
    
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    
    prompt = (payload.get('prompt') or '').strip()
    image_url = payload.get('image_url', '').strip()
    
    if not prompt:
        return JsonResponse({'error': 'prompt is required'}, status=400)
    
    # Detect intent: search, caption, or general chat
    prompt_lower = prompt.lower()
    search_keywords = ['search', 'find', 'look for', 'match', 'similar', 'image like']
    caption_keywords = ['caption', 'describe', 'what is', 'what\'s in', 'explain', 'tell me about']
    
    is_search = any(kw in prompt_lower for kw in search_keywords)
    is_caption = any(kw in prompt_lower for kw in caption_keywords) or image_url
    
    # Route 1: Image search
    if is_search and not is_caption:
        try:
            # Extract search term from prompt
            search_term = prompt
            for kw in search_keywords:
                search_term = search_term.lower().replace(kw, '').strip()
            
            if not search_term:
                search_term = prompt
            
            result_path = clip_search(search_term)
            return JsonResponse({'response': f'Found a match for "{search_term}". Image: {result_path}', 'type': 'search', 'image_url': '/' + result_path})
        except Exception as e:
            return JsonResponse({'response': f'Search failed: {str(e)}', 'type': 'search', 'error': str(e)})
    
    # Route 2: Image caption (if image_url provided or caption intent)
    if is_caption and image_url:
        try:
            # Extract local path from URL
            if image_url.startswith('/'):
                local_path = image_url[1:]
            else:
                local_path = image_url
            
            if os.path.exists(local_path):
                pil_image = Image.open(local_path).convert('RGB')
                inputs = blip_processor(images=pil_image, return_tensors='pt')
                output = blip_model.generate(**inputs, max_length=20)
                caption_text = blip_processor.decode(output[0], skip_special_tokens=True)
                return JsonResponse({'response': f'Caption: {caption_text}', 'type': 'caption'})
            else:
                return JsonResponse({'response': 'Image file not found.', 'type': 'caption', 'error': 'File not found'})
        except Exception as e:
            return JsonResponse({'response': f'Caption generation failed: {str(e)}', 'type': 'caption', 'error': str(e)})
    
    # Route 3: Default to Claude Haiku (general chat)
    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if not api_key:
        return JsonResponse({'response': 'Claude Haiku not configured. Set ANTHROPIC_API_KEY env var to enable.', 'type': 'claude'})
    
    api_url = os.environ.get('ANTHROPIC_API_URL', 'https://api.anthropic.com/v1/responses')
    headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
    body = {'model': os.environ.get('ANTHROPIC_MODEL', 'claude-haiku-4.5'), 'input': prompt}
    
    try:
        r = requests.post(api_url, headers=headers, json=body, timeout=30)
        r.raise_for_status()
        resp_json = r.json()
        
        text = None
        if isinstance(resp_json, dict):
            if 'completion' in resp_json:
                text = resp_json['completion']
            elif 'output' in resp_json:
                text = resp_json['output']
            elif 'choices' in resp_json and isinstance(resp_json['choices'], list) and resp_json['choices']:
                first = resp_json['choices'][0]
                text = first.get('text') or first.get('message') or first.get('content')
        
        if text is None:
            text = json.dumps(resp_json)
        
        return JsonResponse({'response': text, 'type': 'claude'})
    except requests.RequestException as e:
        return JsonResponse({'response': f'Claude request failed: {str(e)}', 'type': 'claude', 'error': str(e)})
